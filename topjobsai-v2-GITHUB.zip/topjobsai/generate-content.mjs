/**
 * TopJobsAI — Programmatic Content Generator
 *
 * This script generates a full industry data object for any industry
 * using the Claude API. Run it once per industry to populate your site.
 *
 * Usage:
 *   node generate-content.mjs "nursing" "healthcare"
 *   node generate-content.mjs "corporate law" "legal"
 *   node generate-content.mjs "supply chain" "logistics"
 *
 * Output: src/data/industries-generated/{slug}.json
 */

import fs from 'fs';
import path from 'path';

const INDUSTRIES_TO_GENERATE = [
  // Healthcare cluster
  { industry: "nursing", cluster: "healthcare" },
  { industry: "mental health therapy", cluster: "healthcare" },
  { industry: "medical imaging", cluster: "healthcare" },
  { industry: "pharmacy", cluster: "healthcare" },
  { industry: "physical therapy", cluster: "healthcare" },
  { industry: "health insurance", cluster: "healthcare" },
  // Finance cluster
  { industry: "accounting", cluster: "finance" },
  { industry: "insurance underwriting", cluster: "finance" },
  { industry: "wealth management", cluster: "finance" },
  { industry: "commercial real estate finance", cluster: "finance" },
  // Legal cluster
  { industry: "contract law", cluster: "legal" },
  { industry: "compliance and regulatory", cluster: "legal" },
  { industry: "intellectual property", cluster: "legal" },
  // Education cluster
  { industry: "K-12 teaching", cluster: "education" },
  { industry: "higher education", cluster: "education" },
  { industry: "corporate training and L&D", cluster: "education" },
  { industry: "tutoring and test prep", cluster: "education" },
  // Marketing cluster
  { industry: "content marketing", cluster: "marketing" },
  { industry: "SEO and search marketing", cluster: "marketing" },
  { industry: "social media management", cluster: "marketing" },
  { industry: "advertising and media buying", cluster: "marketing" },
  // Supply chain cluster
  { industry: "warehouse and fulfillment", cluster: "logistics" },
  { industry: "last-mile delivery", cluster: "logistics" },
  { industry: "procurement", cluster: "logistics" },
  // Retail cluster
  { industry: "fashion retail", cluster: "retail" },
  { industry: "grocery and CPG", cluster: "retail" },
  { industry: "e-commerce operations", cluster: "retail" },
];

async function generateIndustryData(industry, cluster) {
  const slug = industry.toLowerCase().replace(/[^a-z0-9]+/g, '-');

  const prompt = `You are a career data expert writing for TopJobsAI.com, a website helping professionals transition into AI careers.

Generate a comprehensive JSON data object for the "${industry}" industry (cluster: ${cluster}).

Return ONLY valid JSON matching this exact schema — no markdown, no explanation, just raw JSON:

{
  "slug": "${slug}",
  "name": "string (short display name, title case, max 4 words)",
  "emoji": "string (1 relevant emoji)",
  "guideCount": number (realistic between 15-65),
  "metaDescription": "string (SEO meta description, 140-160 chars, include '2025', include salary range)",
  "intro": "string (2-3 sentences, compelling, specific to this industry's AI transformation)",
  "avgSalary": "string (e.g. '$105k')",
  "yoyGrowth": number (realistic % growth, between 30-120),
  "openRoles": number (realistic US market estimate),
  "noCodingRoles": boolean,
  "topRoles": [
    {
      "title": "string",
      "salary": "string (e.g. '$85k–$110k')",
      "description": "string (2 sentences, specific)",
      "remote": boolean,
      "noCoding": boolean,
      "hot": boolean
    }
  ],
  "skillsIntro": "string (1 sentence intro to skills section)",
  "skills": [
    { "name": "string", "importance": number (0-100) }
  ],
  "transitionSteps": [
    { "title": "string (short, action-oriented)", "desc": "string (2-3 sentences, specific and actionable)" }
  ],
  "faqs": [
    { "question": "string", "answer": "string (3-5 sentences, specific)" }
  ],
  "related": [
    { "slug": "string", "name": "string", "emoji": "string", "avgSalary": "string" }
  ]
}

Requirements:
- topRoles: 3-5 roles specific to this industry, mix of technical and non-technical
- skills: 6-8 skills, weighted realistically
- transitionSteps: exactly 4 steps, actionable and specific
- faqs: 2-4 questions specific to this industry (not generic AI job questions)
- related: 3-4 related industries with accurate slugs
- All salary data should be realistic for 2025 US market
- Focus on HOW domain expertise is an asset, not a liability`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4000,
        messages: [{ role: "user", content: prompt }]
      })
    });

    const data = await response.json();
    const text = data.content[0].text.trim();

    // Parse and validate
    const parsed = JSON.parse(text);

    // Write to file
    const outputDir = './src/data/generated';
    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

    const outputPath = path.join(outputDir, `${slug}.json`);
    fs.writeFileSync(outputPath, JSON.stringify(parsed, null, 2));

    console.log(`✅ Generated: ${industry} → ${outputPath}`);
    return parsed;

  } catch (err) {
    console.error(`❌ Failed: ${industry}`, err.message);
    return null;
  }
}

async function generateAll() {
  console.log(`\n🚀 TopJobsAI Content Generator`);
  console.log(`Generating ${INDUSTRIES_TO_GENERATE.length} industry pages...\n`);

  let success = 0;
  let failed = 0;

  for (const { industry, cluster } of INDUSTRIES_TO_GENERATE) {
    await generateIndustryData(industry, cluster);
    success++;
    // Rate limit: wait 1 second between requests
    await new Promise(r => setTimeout(r, 1000));
  }

  console.log(`\n✅ Done! ${success} generated, ${failed} failed.`);
  console.log(`Files saved to: src/data/generated/`);
  console.log(`\nNext: merge generated JSON files into src/data/industries.json`);
}

// Run
if (!process.env.ANTHROPIC_API_KEY) {
  console.error('❌ Set your ANTHROPIC_API_KEY environment variable first:');
  console.error('   export ANTHROPIC_API_KEY=sk-ant-...');
  process.exit(1);
}

generateAll();
