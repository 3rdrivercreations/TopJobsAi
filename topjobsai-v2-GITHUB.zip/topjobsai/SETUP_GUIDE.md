# TopJobsAI — Setup Guide (No Experience Required)

You have a fully built website. Here's how to get it live in about 30 minutes.

---

## Step 1: Install the tools you need (5 minutes)

You need two free programs: **Node.js** and **Git**.

1. Go to https://nodejs.org and download the "LTS" version (the green button)
2. Install it like any normal program (click Next, Next, Finish)
3. Go to https://git-scm.com/downloads and download Git for your computer
4. Install it (all default settings are fine)

To check they installed: open a **Terminal** (Mac: press Cmd+Space, type "terminal") or **Command Prompt** (Windows: press Windows key, type "cmd") and type:
```
node --version
```
You should see a number like `v20.11.0`. That means it worked.

---

## Step 2: Set up your project (5 minutes)

1. Download your TopJobsAI project files (click the download button above)
2. Unzip the folder somewhere easy to find (like your Desktop)
3. In your Terminal/Command Prompt, navigate to the folder:
   ```
   cd Desktop/topjobsai
   ```
4. Install the project's dependencies (this downloads Astro):
   ```
   npm install
   ```
   Wait for it to finish (takes 1–2 minutes).

5. Start your local preview:
   ```
   npm run dev
   ```
6. Open your browser and go to: **http://localhost:4321**

You're now seeing your website locally. 

---

## Step 3: Deploy to Cloudflare (free hosting) — 10 minutes

1. Go to https://github.com and create a free account if you don't have one
2. Create a new repository called `topjobsai`
3. In your Terminal, run these commands one at a time:
   ```
   git init
   git add .
   git commit -m "Initial launch"
   git remote add origin https://github.com/YOURUSERNAME/topjobsai.git
   git push -u origin main
   ```
   (Replace YOURUSERNAME with your GitHub username)

4. Go to https://pages.cloudflare.com and sign up free
5. Click "Create a project" → "Connect to Git" → select your `topjobsai` repo
6. Set the build settings:
   - **Build command:** `npm run build`
   - **Output directory:** `dist`
7. Click "Save and Deploy"

Cloudflare will build and deploy your site automatically. In about 2 minutes you'll have a live URL like `topjobsai.pages.dev`.

---

## Step 4: Connect your domain

1. Buy **TopJobsAI.com** at https://cloudflare.com/products/registrar (cheapest option — Cloudflare sells at cost)
2. In your Cloudflare Pages project, go to "Custom Domains"
3. Add `topjobsai.com`
4. Cloudflare handles the DNS automatically — done!

---

## Step 5: Generate your 500+ pages (the magic part)

1. Get a Claude API key at https://console.anthropic.com (takes 5 minutes, starts ~$5 credit free)
2. In your Terminal, set your key:
   - **Mac:** `export ANTHROPIC_API_KEY=sk-ant-YOUR-KEY-HERE`
   - **Windows:** `set ANTHROPIC_API_KEY=sk-ant-YOUR-KEY-HERE`
3. Run the content generator:
   ```
   node generate-content.mjs
   ```
4. It will generate 28 new industry pages automatically (takes ~5 minutes, costs about $2)
5. The generated files go into `src/data/generated/`
6. Copy the content into `src/data/industries.json` to add new pages to your site
7. Push to GitHub: `git add . && git commit -m "New pages" && git push`
8. Cloudflare automatically rebuilds and deploys your site

---

## Making money: affiliate links

Your industry pages already have ZipRecruiter affiliate links built in. To activate them:

1. Sign up for the ZipRecruiter affiliate program at:
   https://www.ziprecruiter.com/affiliate
2. Get your affiliate tracking ID
3. Open `src/pages/industry/[slug].astro`
4. Find the line that says `utm_source=topjobsai` and add your affiliate ID

For display ads (once you hit 10,000 monthly visitors):
- Apply to **Mediavine** at https://www.mediavine.com
- Or start with **Google AdSense** right away at https://adsense.google.com

---

## Updating your site later

Every time you want to add pages or make changes:
1. Make your edits
2. Run: `git add . && git commit -m "Update" && git push`
3. Cloudflare automatically deploys the changes in ~60 seconds

That's it. Your site is live, auto-deploys on every save, and costs $0/month to host.

---

## Need help?

Common issues and solutions:
- **"npm not found"** → Node.js didn't install correctly. Re-download from nodejs.org
- **"permission denied"** → On Mac, prefix commands with `sudo ` (e.g. `sudo npm install`)
- **Pages won't build on Cloudflare** → Check that Build command is exactly `npm run build` and Output directory is exactly `dist`

Questions? The Astro docs are excellent: https://docs.astro.build
