import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://topjobsai.com',
  compressHTML: true,
});
